# Dockerized

# Config nginx

CUSTOM YOUR NGINX CONFIG IN
`nginx/default.conf`

## Usage

```bash
`Open Dockerfile and change SERVER_API_URL to your BACKEND URL or domain before build docker image`
docker build -t wooribank-cms .
docker run --name wooribank-cms -d -p 8080:80 wooribank-cms
