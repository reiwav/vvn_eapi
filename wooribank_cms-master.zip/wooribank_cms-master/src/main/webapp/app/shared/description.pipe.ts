import { Pipe, PipeTransform } from '@angular/core';

import * as dayjs from 'dayjs';

@Pipe({
  name: 'description',
})
export class DescriptionPipe implements PipeTransform {
  transform(value: any): string {
    if (typeof value === 'string') {
      if (value.length > 50) {
        return value.substr(0, 49) + '...';
      }
      return value;
    }
    return '';
  }
}
