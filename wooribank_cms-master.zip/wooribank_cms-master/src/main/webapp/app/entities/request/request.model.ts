import * as dayjs from 'dayjs';
import { IImage } from 'app/entities/image/image.model';

export interface IRequest {
  id?: number;
  requestID?: string | null;
  requestType?: string | null;
  responseBody?: string | null;
  cardType?: number | null;
  processServer?: string | null;
  responseBodyIdentify?: string | null;
  createdAt?: dayjs.Dayjs | null;
  images?: IImage[] | [];
  processTime?: number | null;
  errorMessage?: string | null;
  statusCode?: number | null;
  responseBodyName?: string | null;
  fakeCode?: string | null;
}

export class Request implements IRequest {
  constructor(
    public id?: number,
    public requestID?: string | null,
    public requestType?: string | null,
    public responseBody?: string | null,
    public cardType?: number | null,
    public processServer?: string | null,
    public responseBodyIdentify?: string | null,
    public images?: IImage[] | [],
    public createdAt?: dayjs.Dayjs | null,
    public processTime?: number | null,
    public errorMessage?: string | null,
    public statusCode?: number | null,
    public responseBodyName?: string | null,
    public fakeCode?: string | null
  ) {}
}

export function getRequestIdentifier(request: IRequest): number | undefined {
  return request.id;
}
