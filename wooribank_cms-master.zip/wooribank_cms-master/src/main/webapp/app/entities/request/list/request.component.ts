import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { combineLatest } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { IRequest } from '../request.model';
import * as moment from 'moment';

import { ITEMS_PER_PAGE } from 'app/config/pagination.constants';
import { RequestService } from '../service/request.service';
import { RequestDeleteDialogComponent } from '../delete/request-delete-dialog.component';
import { CommonService } from 'app/entities/common.service';
import * as fileSaver from 'file-saver';

const FORMAT_TIME = 'yyyy-MM-DD';

@Component({
  selector: 'jhi-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss'],
})
export class RequestComponent implements OnInit {
  requests?: IRequest[];
  isLoading = false;
  totalItems = 0;
  itemsPerPage = ITEMS_PER_PAGE;
  page?: number;
  predicate!: string;
  ascending!: boolean;
  ngbPaginationPage = 1;
  requestIDFilter = '';
  responseBodyIdentifyFilter = '';
  responseBodyNameFilter = '';
  requestTypeFilter = '';
  fakeCodeFilter = '';

  selected: any;
  startDate = '';
  endDate = '';
  requestTypes: any[] = [];
  fakeCodes: any[] = [];

  toggleClassName = 'dropdown-menu toggle-show';

  ranges: any = {
    Today: [moment(), moment()],
    Yesterday: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
    'Any Time': [moment().subtract(100, 'year'), moment()],
  };

  constructor(
    protected commonService: CommonService,
    protected requestService: RequestService,
    protected activatedRoute: ActivatedRoute,
    protected router: Router,
    protected modalService: NgbModal
  ) {}

  toggleButton(): void {
    if (this.toggleClassName === 'dropdown-menu toggle-show') {
      this.toggleClassName = 'dropdown-menu toggle-hide';
    } else {
      this.toggleClassName = 'dropdown-menu toggle-show';
    }
  }

  changeDateFilterHandler(): void {
    if (this.selected !== null && typeof this.selected !== 'undefined') {
      this.startDate = this.selected.startDate !== null ? this.selected.startDate.toDate().toISOString() : '';
      this.endDate = this.selected.endDate !== null ? this.selected.endDate.toDate().toISOString() : '';

      this.loadPage();
    }
  }

  changeFilterHandler(): void {
    this.page = 0;
  }

  buildRequestParams(page?: number): any {
    const pageToLoad: number = page ?? this.page ?? 1;
    const req: { [index: string]: any } = {
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.sort(),
    };
    if (this.requestIDFilter !== '') {
      req['requestID.contains'] = this.requestIDFilter;
    }
    if (this.responseBodyIdentifyFilter !== '') {
      req['responseBodyIdentify.contains'] = this.responseBodyIdentifyFilter;
    }
    if (this.responseBodyNameFilter !== '') {
      req['responseBodyName.contains'] = this.responseBodyNameFilter;
    }
    if (this.requestTypeFilter !== '') {
      req['requestType.equals'] = this.requestTypeFilter === 'EMPTY' ? '' : this.requestTypeFilter;
    }
    if (this.fakeCodeFilter !== '') {
      req['fakeCode.equals'] = this.fakeCodeFilter === 'EMPTY' ? '' : this.fakeCodeFilter;
    }
    if (this.startDate !== '' && this.endDate !== '') {
      // req['createdAt.greaterThan'] = this.selected.startDate.format(FORMAT_TIME);
      // req['createdAt.lessThan'] = this.selected.endDate.format(FORMAT_TIME);
      req['createdAt.greaterThan'] = this.startDate;
      req['createdAt.lessThan'] = this.endDate;
    }
    this.commonService.requestType().subscribe((res: HttpResponse<any[]>) => {
      this.requestTypes = res.body ?? [];
    });

    this.commonService.fakeCode().subscribe((res: HttpResponse<any[]>) => {
      this.fakeCodes = res.body ?? [];
    });
    return req;
  }

  export(): void {
    this.isLoading = true;
    const req = this.buildRequestParams();
    this.requestService.export(req).subscribe(response => {
      const today = new Date();

      const blob = new Blob([response.body], { type: 'application/dbase; charset=utf-8' });
      fileSaver.saveAs(blob, `evg_${today.getTime()}.xlsx`);

      this.isLoading = false;
    });
  }

  loadPage(page?: number, dontNavigate?: boolean): void {
    this.isLoading = true;
    const req = this.buildRequestParams(page);
    const pageToLoad = parseInt(req.page, 10) + 1;

    this.requestService.query(req).subscribe(
      (res: HttpResponse<IRequest[]>) => {
        this.isLoading = false;
        this.onSuccess(res.body, res.headers, pageToLoad, !dontNavigate);
      },
      () => {
        this.isLoading = false;
        this.onError();
      }
    );
  }

  ngOnInit(): void {
    this.ascending = false;
    this.handleNavigation();
  }

  trackId(index: number, item: IRequest): number {
    return item.id!;
  }

  delete(request: IRequest): void {
    const modalRef = this.modalService.open(RequestDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.request = request;
    // unsubscribe not needed because closed completes on modal close
    modalRef.closed.subscribe(reason => {
      if (reason === 'deleted') {
        this.loadPage();
      }
    });
  }

  clickLoadPage(): void {
    this.loadPage();
    if (this.toggleClassName === 'dropdown-menu toggle-hide') {
      this.toggleButton();
    }
  }

  protected sort(): string[] {
    const result = [this.predicate + ',' + (this.ascending ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }

  protected handleNavigation(): void {
    combineLatest([this.activatedRoute.data, this.activatedRoute.queryParamMap]).subscribe(([data, params]) => {
      const page = params.get('page');
      const pageNumber = page !== null ? +page : 1;
      const sort = (params.get('sort') ?? data['defaultSort']).split(',');
      const predicate = sort[0];
      const ascending = sort[1] === 'asc';
      const requestID = params.get('requestID');
      const start = params.get('start');
      const end = params.get('end');

      const responseBodyIdentify = params.get('responseBodyIdentify');
      const responseBodyName = params.get('responseBodyName');
      const fakeCode = params.get('fakeCode');

      if (
        pageNumber !== this.page ||
        predicate !== this.predicate ||
        ascending !== this.ascending ||
        requestID !== this.requestIDFilter ||
        responseBodyIdentify !== this.responseBodyIdentifyFilter ||
        responseBodyName !== this.responseBodyNameFilter ||
        fakeCode !== this.fakeCodeFilter ||
        start !== this.startDate ||
        end !== this.endDate
      ) {
        this.predicate = predicate;
        this.ascending = ascending;
        this.requestIDFilter = requestID !== null ? requestID : '';
        this.startDate = start !== null ? start : '';
        this.endDate = end !== null ? end : '';
        if (this.startDate !== '' && this.endDate !== '') {
          this.selected = {
            startDate: moment(Date.parse(this.startDate)),
            endDate: moment(Date.parse(this.endDate)),
          };
        }
        this.responseBodyIdentifyFilter = responseBodyIdentify !== null ? responseBodyIdentify : '';
        this.responseBodyNameFilter = responseBodyName !== null ? responseBodyName : '';
        this.fakeCodeFilter = fakeCode !== null ? fakeCode : '';
        this.loadPage(pageNumber, true);
      }
    });
  }

  protected onSuccess(data: IRequest[] | null, headers: HttpHeaders, page: number, navigate: boolean): void {
    this.totalItems = Number(headers.get('X-Total-Count'));
    this.page = page;
    if (navigate) {
      const params: { [index: string]: any } = {
        page: this.page,
        size: this.itemsPerPage,
        sort: this.predicate + ',' + (this.ascending ? 'asc' : 'desc'),
      };
      if (this.requestIDFilter !== '') {
        params['requestID'] = this.requestIDFilter;
      }
      if (this.responseBodyIdentifyFilter !== '') {
        params['responseBodyIdentify'] = this.responseBodyIdentifyFilter;
      }
      if (this.fakeCodeFilter !== '') {
        params['fakeCode'] = this.fakeCodeFilter;
      }
      if (this.responseBodyNameFilter !== '') {
        params['responseBodyName'] = this.responseBodyNameFilter;
      }
      if (this.selected !== null && typeof this.selected !== 'undefined') {
        params['start'] = this.startDate;
        params['end'] = this.endDate;
      }
      this.router.navigate(['/request'], {
        queryParams: params,
      });
    }
    this.requests = data ?? [];
    this.ngbPaginationPage = this.page;
  }

  protected onError(): void {
    console.log('err');
    // this.ngbPaginationPage = this.page ?? 1;
  }
}
