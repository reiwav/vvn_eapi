import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import * as dayjs from 'dayjs';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';

import { IRequest, Request } from '../request.model';
import { RequestService } from '../service/request.service';

@Component({
  selector: 'jhi-request-update',
  templateUrl: './request-update.component.html',
})
export class RequestUpdateComponent implements OnInit {
  isSaving = false;

  editForm = this.fb.group({
    id: [],
    requestID: [],
    requestType: [],
    responseBody: [],
    cardType: [],
    processServer: [],
    responseBodyIdentify: [],
    createdAt: [],
    processTime: [],
    errorMessage: [],
    statusCode: [],
    responseBodyName: [],
    fakeCode: [],
  });

  constructor(protected requestService: RequestService, protected activatedRoute: ActivatedRoute, protected fb: FormBuilder) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ request }) => {
      if (request.id === undefined) {
        const today = dayjs().startOf('day');
        request.createdAt = today;
      }

      this.updateForm(request);
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const request = this.createFromForm();
    if (request.id !== undefined) {
      this.subscribeToSaveResponse(this.requestService.update(request));
    } else {
      this.subscribeToSaveResponse(this.requestService.create(request));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IRequest>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(request: IRequest): void {
    this.editForm.patchValue({
      id: request.id,
      requestID: request.requestID,
      requestType: request.requestType,
      responseBody: request.responseBody,
      cardType: request.cardType,
      processServer: request.processServer,
      responseBodyIdentify: request.responseBodyIdentify,
      createdAt: request.createdAt ? request.createdAt.format(DATE_TIME_FORMAT) : null,
      processTime: request.processTime,
      errorMessage: request.errorMessage,
      statusCode: request.statusCode,
      responseBodyName: request.responseBodyName,
      fakeCode: request.fakeCode,
    });
  }

  protected createFromForm(): IRequest {
    return {
      ...new Request(),
      id: this.editForm.get(['id'])!.value,
      requestID: this.editForm.get(['requestID'])!.value,
      requestType: this.editForm.get(['requestType'])!.value,
      responseBody: this.editForm.get(['responseBody'])!.value,
      cardType: this.editForm.get(['cardType'])!.value,
      processServer: this.editForm.get(['processServer'])!.value,
      responseBodyIdentify: this.editForm.get(['responseBodyIdentify'])!.value,
      createdAt: this.editForm.get(['createdAt'])!.value ? dayjs(this.editForm.get(['createdAt'])!.value, DATE_TIME_FORMAT) : undefined,
      processTime: this.editForm.get(['processTime'])!.value,
      errorMessage: this.editForm.get(['errorMessage'])!.value,
      statusCode: this.editForm.get(['statusCode'])!.value,
      responseBodyName: this.editForm.get(['responseBodyName'])!.value,
      fakeCode: this.editForm.get(['fakeCode'])!.value,
    };
  }
}
