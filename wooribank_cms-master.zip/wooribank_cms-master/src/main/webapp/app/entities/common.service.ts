import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { IRequest } from 'app/entities/request/request.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export type EntityArrayResponseType = HttpResponse<any[]>;

@Injectable({ providedIn: 'root' })
export class CommonService {
  public resourceUrl = this.applicationConfigService.getEndpointFor('api/common');

  constructor(protected http: HttpClient, private applicationConfigService: ApplicationConfigService) {}

  requestType(): Observable<EntityArrayResponseType> {
    return this.http
      .get<IRequest[]>(`${this.resourceUrl}/requestTypes`, { observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  fakeCode(): Observable<EntityArrayResponseType> {
    return this.http
      .get<IRequest[]>(`${this.resourceUrl}/fakeCodes`, { observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    return res;
  }
}
