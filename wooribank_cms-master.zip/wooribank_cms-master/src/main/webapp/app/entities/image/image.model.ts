export interface IImage {
  id?: number;
  requestID?: string | null;
  filePath?: string | null;
  hash?: string | null;
  type?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  referID?: number | null;
}

export class Image implements IImage {
  constructor(
    public id?: number,
    public requestID?: string | null,
    public filePath?: string | null,
    public hash?: string | null,
    public type?: string | null,
    public createdAt?: string | null,
    public updatedAt?: string | null,
    public referID?: number | null
  ) {}
}

export function getImageIdentifier(image: IImage): number | undefined {
  return image.id;
}
