module.exports = {
  '{,src/**/,webpack/}*.{md,json,yml,html,js,ts,tsx,css,scss}': ['prettier --write'],
};
